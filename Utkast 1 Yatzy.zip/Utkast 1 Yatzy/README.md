Team11-Webteknikker og Teamarbeid

Medlemmer i Team 11:
- Mina
- Edvard
- Vetle
- Per Morten
- Sigrun
- Mats


Her forklares funksjonene i yatzy.js

fuction kasteKnapp()
